export {default as Header} from './header/header';
export {default as Footer} from './footer/footer';
export {default as Slider} from './homeComponets/slider/slider';
export {default as Layout} from './homeComponets/layout/layout';
export {default as Cards} from './homeComponets/cards/card';
export {default as CitiesCards} from './homeComponets/cards/card2';
export {default as Trends} from './homeComponets/trands/trends';
export {default as HowItWorks} from './homeComponets/howItWork/howItWorks';
export {default as ExploreDestination} from './homeComponets/exploreDestination/exploreDestination';
export {default as Experiences} from './homeComponets/experiences/experiences';
export {default as MeetourKreators} from './homeComponets/meetourKreators/meetourKreators';
export {default as SearchBlock} from './searchBlock/searchBlock';


