'use client';
import Link from "next/link";
import Image from "next/image";
import konnect from "../../../../public/assets/images/Logoheader.png";
import { useRouter } from 'next/navigation'
import { useState, useEffect } from "react";
import i18next from "i18next";
import { useTranslation } from "react-i18next";

const Header = () => {
  const router = useRouter()
  const { t } = useTranslation();

  const currentLanguageCode = localStorage.getItem("i18nextLng");
  const [currentLng, setCurrentLng] = useState(currentLanguageCode);
 
  useEffect(() => {
    // localStorage.getItem('')
    if (currentLng === "en") {
      document.body.dir = "ltr";
    } else if (currentLng === "ar") {
      document.body.dir = "rtl";
    }
  });
  const handleChangeLng = (lng) => {
      localStorage.removeItem("lngstyle");
      i18next.changeLanguage(lng);
      localStorage.setItem("lng", lng);
      // localStorage.setItem("lngstyle", currentLng);
  };

  const navLinks = [
    {
      path: "Home",
      display:  `${t("home")}`
    },
    {
      path: "how-it-works",
      display:  `${t("how_it_works")}`
    },
    {
      path: "kreatoe-portal",
      display:  `${t("kreatoe_portal")}`
    },
    {
      path: "guest",
      display:  `${t("guest")}`
    }
  ];
  const currentRoute = router.pathname

  // const currentLanguageCode = localStorage.getItem("i18nextLng") ;

  // const [currentLng, setCurrentLng] = useState(currentLanguageCode);
  // useEffect(() => {
  //   // localStorage.getItem('')
  //   if (currentLng === "en") {
  //     document.body.dir = "ltr";
  //   } else if (currentLng === "ar") {
  //     document.body.dir = "rtl";
  //   }
  // });
  // if (typeof window !== 'undefined' && window.localStorage) {
  //   localStorage.removeItem("lngstyle");
  // }
  // const handleChangeLng = (lng) => {
  //   // i18next.changeLanguage(lng);
  //   // localStorage.setItem("lng", lng);
  //   // localStorage.setItem("lngstyle", currentLng);
  // };
  
  return (
    <>
      <header className="konnectHeader fixed-top">
        <nav className="navbar navbar-expand-lg">
          <div className="container">
          <Link href="/homepage" className="navbar-brand">
                  <Image
                    src={konnect}
                    className=""
                    width={100}
                    alt="..."
                  />
          </Link>
            <button
              className="navbar-toggler"
              type="button"
              data-bs-toggle="collapse"
              data-bs-target="#navbarNav"
              aria-controls="navbarNav"
              aria-expanded="false"
              aria-label="Toggle navigation">
              <span className="navbar-toggler-icon"></span>
            </button>
            <div
              className="collapse navbar-collapse justify-content-end"
              id="navbarNav">
                <form className="d-flex me-auto pl-5 mb-2 mb-lg-0">
                  <input className="form-control mr-auto mr-sm-2" type="search" placeholder="Search by Destination, Kreator...." aria-label="Search" />
                </form>
              <ul className="navbar-nav">
                {navLinks.map((item, index) => (
                  <li className="nav-item" key={index}>
                    <Link href={item.path} className={`nav-link ${currentRoute === item.path ? 'active' : 'xxx'}`}>
                      {item.display}
                    </Link>
                  </li>
                ))}
                {/* <li className="nav-item">
                    <Link href={'/'} className={`nav-link`}  locale="en">
                      En
                    </Link>
                  </li>
                  <li className="nav-item">
                    <Link href="/" className={`nav-link`} locale="ar">
                      Ar
                    </Link>
                  </li> */}
              </ul>
                <select className="select_lan mx-3" onChange={(e) => {
                      handleChangeLng(e.target.value);
                      setCurrentLng(e.target.value);
                 }}>
                  <option value="en">En</option>
                  <option value="ar">عربي</option>
                </select>
            </div>
          </div>
        </nav>
      </header>
    </>
  );
};

export default Header;
